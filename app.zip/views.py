from app import app

@app.route('/verify')
def verify():
    pass